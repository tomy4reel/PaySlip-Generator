# Create a List of Workers Dynamically
set.seed(123)  # For reproducibility

# Define number of workers
num_workers <- 400

# Generate worker data
workers <- data.frame(
  id = 1:num_workers,
  name = paste("Worker", 1:num_workers),
  salary = runif(num_workers, 5000, 35000),  # Random salary between $5000 and $35000
  gender = sample(c("Male", "Female"), num_workers, replace = TRUE)
)

# Generate Payment Slips

generate_payment_slips <- function(workers) {
  payment_slips <- workers
  payment_slips$employee_level <- NA
  
  for (i in 1:nrow(workers)) {
    tryCatch({
      if (workers$salary[i] > 10000 & workers$salary[i] < 20000) {
        payment_slips$employee_level[i] <- "A1"
      } else if (workers$salary[i] > 7500 & workers$salary[i] < 30000 & workers$gender[i] == "Female") {
        payment_slips$employee_level[i] <- "A5-F"
      } else {
        payment_slips$employee_level[i] <- "Unclassified"
      }
    }, error = function(e) {
      cat(sprintf("Error processing worker ID %d: %s\n", workers$id[i], e$message))
    })
  }
  
  return(payment_slips)
}

