# Create a List of Workers Dynamically

import random

# Define worker attributes
num_workers = 400
workers = []

# Generate worker data
for i in range(num_workers):
    worker = {
        'id': i + 1,
        'name': f'Worker_{i + 1}',
        'salary': random.uniform(5000, 35000),  # Random salary between $5000 and $35000
        'gender': random.choice(['Male', 'Female'])
    }
    workers.append(worker)

# Generate Payment Slips and Implement Exception Handling

def generate_payment_slips(workers):
    payment_slips = []

    for worker in workers:
        try:
            # Determine employee level based on salary and gender
            if 10000 < worker['salary'] < 20000:
                employee_level = "A1"
            elif 7500 < worker['salary'] < 30000 and worker['gender'] == 'Female':
                employee_level = "A5-F"
            else:
                employee_level = "Unclassified"

            # Create payment slip
            slip = {
                'id': worker['id'],
                'name': worker['name'],
                'salary': worker['salary'],
                'gender': worker['gender'],
                'employee_level': employee_level
            }
            payment_slips.append(slip)
        except Exception as e:
            print(f"Error processing worker {worker['id']}: {e}")

    return payment_slips


